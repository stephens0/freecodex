const qrcode = require('qrcode-terminal');
const { Client, LocalAuth } = require('whatsapp-web.js');
const { EditPhotoHandler } = require('./feature/edit_foto');
const { ChatAIHandler } = require('./feature/chat_ai');
const { GenerateImageHandler } = require('./feature/dall-e');

const client = new Client({
  authStrategy: new LocalAuth()
});

client.on('qr', qr => {
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('Client is ready!');
});

client.on('message', async msg => {
  const text = msg.body.toLowerCase() || '';

  // Vérifier l'état
  if (text === 'salut') {
    msg.reply('Bonjour, comment allez-vous ?');
    return;
  } else if (text === 'quel est ton nom ?') {
    msg.reply('Mon nom est Clever, un bot intelligent.');
    return;
  } else if (text === 'quel est le nom de ton développeur ?') {
    msg.reply('Mon développeur s\'appelle Dekscrypt.');
    return;
  } else if (text === 'qui est ton développeur ?') {
    msg.reply('Mon développeur s\'appelle Dekscrypt.');
    return;
  } else if (text === 'qui t\'a développé ?') {
    msg.reply('Je suis développé par Dekscrypt, un développeur passionné.');
    return;
  } else if (text === 'qui est Dekscrypt ?') {
    msg.reply('Dekscrypt est un développeur talentueux et créatif. Il a une vaste expérience dans la programmation et il aime créer des solutions innovantes.');
    return;
  } else if (text.includes("#edit_bg/")) {
    await EditPhotoHandler(text, msg);
    return;
  } else if (text === 'générer une image') {
    msg.reply('Veuillez fournir une description pour générer une image.');
    return;
  }

  if (text.startsWith('générer une image ')) {
    const description = text.substring('générer une image '.length);
    const imageSize = '1024x1024';
    await GenerateImageHandler(description, imageSize, msg);
    return;
  }

  // Répondre automatiquement à tous les messages
  await ChatAIHandler(text, msg);
});

client.initialize();
