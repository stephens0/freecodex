const fs = require('fs');
const axios = require('axios');
const { openai } = require('../config');

const GenerateImageHandler = async (description, imageSize, msg) => {
  try {
    const response = await openai.davinci('chat-davinci-003', {
      messages: [
        { role: 'system', content: 'You are a painter.' },
        { role: 'user', content: description },
      ],
      max_tokens: 100,
      temperature: 0.8,
      n: 1,
      stop: ['\n', 'User:'],
    });

    const imageURL = response.data.choices[0].message.content;

    const imageBuffer = await axios.get(imageURL, { responseType: 'arraybuffer' });
    const imageBase64 = Buffer.from(imageBuffer.data, 'binary').toString('base64');

    msg.reply({
      body: imageBase64,
      mimetype: 'image/png',
      filename: 'generated_image.png'
    });
  } catch (error) {
    console.error('Erreur lors de la génération de l\'image :', error.message);
    msg.reply('Une erreur s\'est produite lors de la génération de l\'image.');
  }
};

module.exports = {
  GenerateImageHandler
};
