module.exports = {
    API_KEY_RM_BG: "LCfYZDwbJqdSkDetnwdJjnzJ",
    API_KEY_OPEN_AI: "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"
}